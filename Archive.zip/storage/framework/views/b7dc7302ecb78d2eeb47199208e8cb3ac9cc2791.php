<?php $__env->startSection('content'); ?>
    <div>
        <div class="text_center"><b><?php echo e('Part Acquisition Contact Form'); ?></b></div>
        <ul>
            <li>Name: <?php echo e($name); ?></li>
            <li>Phone: <?php echo e($phone); ?></li>
            <li>Email: <?php echo e($email); ?></li>
            <li>Detailed list of parts required: <?php echo e($detail); ?></li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/miraclegabriel/Projects/sendemail/resources/views/mails/partacquisition.blade.php ENDPATH**/ ?>