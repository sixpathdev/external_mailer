<?php $__env->startSection('content'); ?>
    <div>
        <div class="text_center"><?php echo e('Winter Contact Form'); ?></div>
        <ul>
            <li>Name: <?php echo e($name); ?></li>
            <li>Phone: <?php echo e($phone); ?></li>
            <li>Email: <?php echo e($email); ?></li>
            <li>Boat Loa: <?php echo e($loa); ?></li>
            <li>Preferred location: <?php echo e($location); ?></li>
            <li>Type: <?php echo e($type); ?></li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/miraclegabriel/Projects/sendemail/resources/views/mails/moorage.blade.php ENDPATH**/ ?>