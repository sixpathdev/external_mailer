<?php $__env->startSection('content'); ?>
    <div>
        <div class="text_center"><b><?php echo e('Transport Contact Form'); ?></b></div>
        <ul>
            <li>Name: <?php echo e($name); ?></li>
            <li>Phone: <?php echo e($phone); ?></li>
            <li>Email: <?php echo e($email); ?></li>
            <li>Start Location: <?php echo e($start_location); ?></li>
            <li>End Location: <?php echo e($end_location); ?></li>
            <li>Dry Weight: <?php echo e($dry_weight); ?></li>
            <li>Boat Loa: <?php echo e($loa); ?></li>
            <li>Beam: <?php echo e($beam); ?></li>
            <li>Height: <?php echo e($height); ?></li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/miraclegabriel/Projects/sendemail/resources/views/mails/transport.blade.php ENDPATH**/ ?>