<?php $__env->startSection('content'); ?>
    <div>
        <div class="text_center"><?php echo e('Halout Contact Form'); ?></div>
        <ul>
            <li>Name: <?php echo e($name); ?></li>
            <li>Phone: <?php echo e($phone); ?></li>
            <li>Email: <?php echo e($email); ?></li>
            <li>Boat Model: <?php echo e($boatmodel); ?></li>
            <li>Dry Weight: <?php echo e($dryweight); ?></li>
            <li>LOA: <?php echo e($loa); ?></li>
            <li>Beam: <?php echo e($beam); ?></li>
            <li>Height: <?php echo e($height); ?></li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/miraclegabriel/Projects/sendemail/resources/views/mails/halout.blade.php ENDPATH**/ ?>